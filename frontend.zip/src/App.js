import React, { useState, useEffect } from "react";
import axios from "axios";

function App() {
  const [lookupTypes, setLookupTypes] = useState([]);
  const [category, setCategory] = useState("");
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/lookup-types")
      .then(res => setLookupTypes(res.data))
      .catch(err => console.error(err));
  }, []);

  useEffect(() => {
    if (category) {
      axios.get(`http://localhost:5000/api/data?category=${category}`)
        .then(res => setData(res.data))
        .catch(err => console.error(err));
    }
  }, [category]);

  return (
    <div style={{ backgroundColor: "#eaf0f7", minHeight: "100vh", padding: "40px 0" }}>
      <div style={{
        backgroundColor: "#fff",
        maxWidth: "600px",
        margin: "auto",
        padding: "30px",
        borderRadius: "10px",
        boxShadow: "0 0 10px rgba(0,0,0,0.1)"
      }}>
        <h2 style={{ color: "#007bff" }}>GLB Lookup Information</h2>
        <p>Select a lookup category:</p>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          style={{ width: "100%", padding: "10px", marginTop: "10px" }}
        >
          <option value="">-- Select Category --</option>
          {lookupTypes.map((type, idx) => (
            <option key={idx} value={type}>{type}</option>
          ))}
        </select>

        {data.length > 0 && (
          <table style={{ width: "100%", marginTop: "20px", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {Object.keys(data[0]).map((key) => (
                  <th key={key} style={{ textAlign: "left", padding: "8px", borderBottom: "1px solid #ccc" }}>{key}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, idx) => (
                <tr key={idx}>
                  {Object.values(row).map((val, i) => (
                    <td key={i} style={{ padding: "8px", borderBottom: "1px solid #eee" }}>{val}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default App;
