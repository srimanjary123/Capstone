const express = require("express");
const cors = require("cors");
const sql = require("mssql");
const pool = require("./db");

const app = express();
app.use(cors());

app.get("/api/data", async (req, res) => {
  const { category } = req.query;
  if (!category) return res.status(400).json({ error: "Missing category" });

  try {
    await pool.connect();
    const result = await pool.request()
      .input("category", sql.VarChar, category)
      .query("SELECT * FROM glb_Lookups WHERE Category = @category");

    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
