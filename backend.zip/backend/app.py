from flask import Flask, request, jsonify
import pyodbc
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

conn_str = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=localhost,1433;"
    "DATABASE=SrimanjaryDB;"
    "UID=sa;"
    "PWD=YourNewStrongPassword123!;"
)


@app.route("/api/data", methods=["GET"])
def get_data_by_category():
    category = request.args.get("category")
    if not category:
        return jsonify({"error": "Category is required"}), 400
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM glb_Lookups WHERE LookupCode = ?", (category,))
        columns = [col[0] for col in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return jsonify(results)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/lookup-types", methods=["GET"])
def get_lookup_types():
    try:
        conn = pyodbc.connect(conn_str)
        print("Connection successful",conn)
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT LookupCode FROM glb_Lookups;")
        categories = [row[0] for row in cursor.fetchall()]
        return jsonify(categories)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
