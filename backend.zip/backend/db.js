const sql = require("mssql");

const config = {
  server: "sqlserver",
  database: "SrimanjaryDB",
  user: "sa",
  password: "YourStrong@Passw0rd",
  options: {
    trustServerCertificate: true,
    encrypt: false,
  },
};

const pool = new sql.ConnectionPool(config);
module.exports = pool;
