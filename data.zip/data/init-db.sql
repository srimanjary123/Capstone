USE [master];
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'SrimanjaryDB')
BEGIN
    CREATE DATABASE [SrimanjaryDB]
    ON (FILENAME = N'D:\clients_works\python_pro\your-project\your-project\data\Srimanjary.mdf'),
       (FILENAME = N'D:\clients_works\python_pro\your-project\your-project\data\Srimanjary_log.ldf')
    FOR ATTACH;
END;
GO

use SrimanjaryDB;
SELECT * FROM glb_Lookups;
SELECT TOP 10 * FROM glb_Lookups;
SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'glb_Lookups';
